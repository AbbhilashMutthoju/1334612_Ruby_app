class Category < ApplicationRecord
	has_many:products
end
